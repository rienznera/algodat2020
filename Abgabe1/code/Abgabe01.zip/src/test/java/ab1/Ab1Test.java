package ab1;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class Ab1Test {
	@Test
	public void failBecauseOfMissingTests() {
		Assertions.fail("Test will follow");
	}
}
